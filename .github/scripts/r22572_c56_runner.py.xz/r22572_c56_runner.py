from __future__ import annotations
import argparse, hashlib, json, math, os, random, re, shutil, sys
from collections import defaultdict
from pathlib import Path

SEED=22572
ADAPTER_REPO='Hanno-Labs/bosun-xs'
ADAPTER_REV='31129f876462c8b0ec3f360b4c82ab03c430f43e'
BASE_REPO='Qwen/Qwen3-Reranker-0.6B'
EXPECTED_YES_ID=9693
EXPECTED_NO_ID=2152
EXPECTED_MAX_LEN=3072

RULE_TEXT={
 'same_account':'Connected only if both findings refer to the same account identifier.',
 'same_city':'Connected only if both findings concern the same city.',
 'not_same_entity':'Connected only if the two findings do NOT concern the same named entity.',
 'same_entity':'Connected only if both findings concern the same named entity.',
 'same_status':'Connected only if both findings report the same status.',
 'same_account_diff_city':'Connected only if both findings refer to the same account identifier AND they concern different cities.',
 'a_supersedes_b':'Connected only if Finding A explicitly supersedes the release described by Finding B.',
}
QUERY='These two findings share the specified relationship.'

def sha_bytes(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def canon(obj)->bytes:return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()

def fact_text(which,entity,account,city,status,amount,sector,version=None,supersedes=None):
    s=(f"Finding {which} reports entity {entity}, account {account}, city {city}, "
       f"status {status}, amount {amount:.1f} billion dollars, sector {sector}.")
    if version is not None:
        s += f" It describes release {version}."
    if supersedes is not None:
        s += f" It explicitly says release {version} supersedes release {supersedes}."
    return s

def parse_fact(s:str):
    pat=(r"entity ([A-Za-z0-9_-]+), account ([A-Za-z0-9_-]+), city ([A-Za-z0-9_-]+), "
         r"status ([A-Za-z0-9_-]+), amount ([0-9.]+) billion dollars, sector ([A-Za-z0-9_-]+)\.")
    m=re.search(pat,s); assert m,s
    d={'entity':m.group(1),'account':m.group(2),'city':m.group(3),'status':m.group(4),'amount':float(m.group(5)),'sector':m.group(6)}
    vm=re.search(r"It describes release ([A-Za-z0-9_.-]+)\.",s)
    if vm:d['version']=vm.group(1)
    sm=re.search(r"explicitly says release ([A-Za-z0-9_.-]+) supersedes release ([A-Za-z0-9_.-]+)\.",s)
    if sm:d['supersedes']=sm.group(2)
    return d

def verifier_b(case):
    a=parse_fact(case['a']); b=parse_fact(case['b']); r=case['rule_key']
    if r=='same_account':return int(a['account']==b['account'])
    if r=='same_city':return int(a['city']==b['city'])
    if r=='same_entity':return int(a['entity']==b['entity'])
    if r=='not_same_entity':return int(a['entity']!=b['entity'])
    if r=='same_status':return int(a['status']==b['status'])
    if r=='same_account_diff_city':return int(a['account']==b['account'] and a['city']!=b['city'])
    if r=='a_supersedes_b':return int(a.get('supersedes')==b.get('version'))
    raise KeyError(r)

def build_suite():
    rng=random.Random(SEED)
    entities=[f'Entity{c}' for c in 'ABCDEFGHJKLMNPQRSTUVWXYZ']
    accounts=[f'AC{100+i}' for i in range(80)]
    cities=['Lagos','Kano','Accra','Nairobi','Dakar','Tunis','Riga','Oslo']
    statuses=['OPEN','CLOSED','PAUSED']
    sectors=['banking','energy','logistics','health','telecom']
    cases=[]; cid=0
    def attrs(i):
        return dict(entity=entities[i%len(entities)],account=accounts[i%len(accounts)],city=cities[i%len(cities)],status=statuses[i%len(statuses)],amount=0.4+0.3*(i%8),sector=sectors[i%len(sectors)])
    def add(part,rule,a,b,label,group=None):
        nonlocal cid
        c={'id':f'C56-{cid:03d}','partition':part,'rule_key':rule,'instruction':RULE_TEXT[rule],'query':QUERY,'a':a,'b':b,'label':int(label),'pair_group':group};cid+=1
        assert verifier_b(c)==c['label'],(c,verifier_b(c));cases.append(c)
    # 64 rule-flip cases = 32 pairs, each same docs with one positive and one negative rule.
    for i in range(32):
        x=attrs(i); y=attrs(i+17)
        if i%2==0:
            y['account']=x['account']
            if y['city']==x['city']: y['city']=cities[(cities.index(x['city'])+1)%len(cities)]
            pos='same_account'; neg='same_city'
        else:
            y['city']=x['city']
            if y['account']==x['account']: y['account']=accounts[(i+33)%len(accounts)]
            pos='same_city'; neg='same_account'
        a=fact_text('A',**x); b=fact_text('B',**y); g=f'flip-{i:02d}'
        add('rule_flip',pos,a,b,1,g); add('rule_flip',neg,a,b,0,g)
    # 48 negation cases = 24 same docs evaluated under same_entity and not_same_entity.
    for i in range(24):
        x=attrs(40+i); y=attrs(64+i)
        same=(i%2==0)
        y['entity']=x['entity'] if same else entities[(entities.index(x['entity'])+3)%len(entities)]
        a=fact_text('A',**x);b=fact_text('B',**y);g=f'neg-{i:02d}'
        add('negation','same_entity',a,b,int(same),g)
        add('negation','not_same_entity',a,b,int(not same),g)
    # 48 conjunction cases, 24 positive and 24 near-miss negatives.
    for i in range(48):
        x=attrs(90+i); y=attrs(140+i)
        if i<24:
            y['account']=x['account']; y['city']=cities[(cities.index(x['city'])+1)%len(cities)]; lab=1
        elif i%2==0:
            y['account']=accounts[(i+51)%len(accounts)]; y['city']=cities[(cities.index(x['city'])+1)%len(cities)]; lab=0
        else:
            y['account']=x['account']; y['city']=x['city']; lab=0
        add('conjunction','same_account_diff_city',fact_text('A',**x),fact_text('B',**y),lab)
    # 48 directional cases: positive A supersedes B; negative is swapped order.
    for i in range(24):
        x=attrs(170+i); y=attrs(200+i); old=f'R{i%9+1}.0'; new=f'R{i%9+2}.0'
        xa=dict(x,version=new,supersedes=old); yb=dict(y,version=old,supersedes=None)
        a=fact_text('A',**xa);b=fact_text('B',**yb);g=f'dir-{i:02d}'
        add('directional','a_supersedes_b',a,b,1,g)
        # swap visible findings but preserve labels from rule direction
        add('directional','a_supersedes_b',fact_text('A',**yb),fact_text('B',**xa),0,g)
    # 48 confirmation: same-status rule, balanced.
    for i in range(48):
        x=attrs(230+i);y=attrs(280+i);same=i<24
        y['status']=x['status'] if same else statuses[(statuses.index(x['status'])+1)%len(statuses)]
        add('confirmation','same_status',fact_text('A',**x),fact_text('B',**y),int(same))
    assert len(cases)==256
    assert sum(c['label'] for c in cases)==128
    assert all(verifier_b(c)==c['label'] for c in cases)
    return cases

def mutation_smoke(cases):
    # independent verifier must reject label flips and directional swaps.
    flip_detect=sum(verifier_b(dict(c,label=1-c['label']))!=1-c['label'] for c in cases[:64])
    dirs=[c for c in cases if c['partition']=='directional']
    swap_detect=0
    for c in dirs[:24]:
        m=dict(c,a=c['b'].replace('Finding B','Finding A',1),b=c['a'].replace('Finding A','Finding B',1),label=1-c['label'])
        if verifier_b(m)==m['label']: swap_detect+=1
    return {'verifier_a_contract_pass':len(cases),'verifier_b_contract_pass':sum(verifier_b(c)==c['label'] for c in cases),'label_flip_mutation_detected':flip_detect,'direction_swap_mutation_pass':swap_detect}

def preseal(out:Path):
    out.mkdir(parents=True,exist_ok=True);cases=build_suite(); smoke=mutation_smoke(cases)
    public_cases=[{k:c[k] for k in ['id','partition','rule_key','instruction','query','a','b','label','pair_group']} for c in cases]
    suite_sha=sha_bytes(canon(public_cases))
    d={
      'schema':'R22572_C56_PREOUTPUT_SEAL_V1','candidate':'C56','weights_present':0,'model_outputs_observed':0,'training_rows_used':0,
      'scientific_question':'Does a programmable relation-judgment LoRA learn rule-conditioned relational steering beyond the generic reranker base, rather than static similarity, and which projection/layer low-rank groups carry any admitted steering effect?',
      'suite_n':len(cases),'suite_sha256':suite_sha,
      'partitions':{p:sum(c['partition']==p for c in cases) for p in sorted({c['partition'] for c in cases})},
      'conditions':['BASE','FULL','RANDOM_RANK_MATCHED','LAYER_SHUFFLED','DOSE_0p25','DOSE_0p50','DOSE_1p50'],
      'causal_if_admitted':['MINUS_Q','MINUS_K','MINUS_V','MINUS_O','MINUS_GATE','MINUS_UP','MINUS_DOWN','MINUS_EARLY','MINUS_MIDDLE','MINUS_LATE'],
      'positive_gate':'composite gain FULL-BASE>=0.06; signed-margin paired bootstrap CI low>0.01; FULL-RANDOM>=0.04; FULL-SHUFFLE>=0.04; rule-flip order gain>=0.08; hard-negative/negation false-positive collateral increase<=0.05; independent verifier B same direction',
      'failure_gate':'composite FULL-BASE<=-0.06 with CI high<-0.01 and FULL materially worse than RANDOM/SHUFFLE, or negation/directional failure control-separated by>=0.08; verifier B same direction',
      'claim_boundary':'Synthetic fresh relational-judgment assay only; no external benchmark/ranking claim; training-time exact Base revision unproven; model-card metrics are not evidence; E4/E5 forbidden without independent replay/fine irredundancy.',
      'runtime_abi_gate':'Exact Qwen3 causal-LM class, logits_to_keep=1, serving yes/no IDs, PEFT lifecycle, safe adapter identifiers and control mutations must pass before binary ingress.',
      'verifier_smoke':smoke,'causal_locked_partitions':['conjunction','directional']
    }
    (out/'C56_PREOUTPUT_SEAL.json').write_text(json.dumps(d,indent=2,ensure_ascii=False))
    (out/'C56_SUITE_DIGEST.json').write_text(json.dumps({'schema':'R22572_C56_SUITE_DIGEST_V1','suite_n':len(cases),'suite_sha256':suite_sha,'raw_cases_exported':False,'reproduce':'python src/lucia_aa_r22572/reproduce_r22572_c56_suite.py'},indent=2))
    print(json.dumps(d,indent=2))

def auc(labels,scores):
    pos=[s for y,s in zip(labels,scores) if y==1];neg=[s for y,s in zip(labels,scores) if y==0]
    if not pos or not neg:return float('nan')
    wins=0.0
    for p in pos:
      for n in neg:wins += 1.0 if p>n else (0.5 if p==n else 0.0)
    return wins/(len(pos)*len(neg))

def metrics(cases,scores):
    labs=[c['label'] for c in cases]; pred=[int(x>=0.5) for x in scores]
    tp=sum(y==1 and p==1 for y,p in zip(labs,pred));tn=sum(y==0 and p==0 for y,p in zip(labs,pred));fp=sum(y==0 and p==1 for y,p in zip(labs,pred));fn=sum(y==1 and p==0 for y,p in zip(labs,pred))
    tpr=tp/max(1,tp+fn);tnr=tn/max(1,tn+fp);bal=(tpr+tnr)/2
    signed=[(1 if y else -1)*(s-0.5) for y,s in zip(labs,scores)]
    groups=defaultdict(list)
    for c,s in zip(cases,scores):
      if c.get('pair_group'):groups[c['pair_group']].append((c['label'],s,c['partition']))
    orders=[]
    for g,vals in groups.items():
      ps=[s for y,s,_ in vals if y==1];ns=[s for y,s,_ in vals if y==0]
      if ps and ns:orders.append(int(sum(ps)/len(ps)>sum(ns)/len(ns)))
    part={}
    for p in sorted({c['partition'] for c in cases}):
      idx=[i for i,c in enumerate(cases) if c['partition']==p]; ll=[labs[i] for i in idx]; ss=[scores[i] for i in idx]; pp=[pred[i] for i in idx]
      part[p]={'n':len(idx),'accuracy':sum(a==b for a,b in zip(ll,pp))/len(idx),'auc':auc(ll,ss),'mean_score':sum(ss)/len(ss),'positive_rate':sum(pp)/len(pp)}
    return {'n':len(cases),'accuracy':sum(a==b for a,b in zip(labs,pred))/len(labs),'balanced_accuracy':bal,'auc':auc(labs,scores),'mean_signed_margin':sum(signed)/len(signed),'pair_order_accuracy':sum(orders)/len(orders) if orders else None,'false_positive_rate':fp/max(1,fp+tn),'partitions':part}

def bootstrap_delta(cases,a_scores,b_scores,iters=1200):
    rng=random.Random(SEED+99); vals=[]; n=len(cases); labs=[c['label'] for c in cases]
    dif=[(1 if y else -1)*((a-0.5)-(b-0.5)) for y,a,b in zip(labs,a_scores,b_scores)]
    for _ in range(iters):
      vals.append(sum(dif[rng.randrange(n)] for _ in range(n))/n)
    vals.sort();return {'mean':sum(dif)/n,'low':vals[int(.025*iters)],'high':vals[int(.975*iters)]}

def execute(out:Path,work:Path):
    import torch
    from huggingface_hub import HfApi, snapshot_download
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import PeftModel
    from safetensors import safe_open
    out.mkdir(parents=True,exist_ok=True); work.mkdir(parents=True,exist_ok=True)
    raw=work/'raw'; variants=work/'variants'; raw.mkdir(exist_ok=True);variants.mkdir(exist_ok=True)
    cases=build_suite(); seal=json.loads((out/'C56_PREOUTPUT_SEAL.json').read_text()); assert sha_bytes(canon(cases))==seal['suite_sha256']
    api=HfApi(); ai=api.model_info(ADAPTER_REPO,revision=ADAPTER_REV,files_metadata=True); assert ai.sha==ADAPTER_REV
    card=(ai.card_data.to_dict() if ai.card_data else {}); assert card.get('license')=='apache-2.0'
    adfiles={s.rfilename:s for s in ai.siblings}; assert 'adapter_model.safetensors' in adfiles and 'adapter_config.json' in adfiles and 'serving.json' in adfiles
    assert not any(re.search(r'\.(bin|pt|pth|pkl|pickle)$',x,re.I) for x in adfiles)
    base_info=api.model_info(BASE_REPO,files_metadata=True); base_rev=base_info.sha; base_card=(base_info.card_data.to_dict() if base_info.card_data else {})
    # Require safe Base model. Tokenizer is taken from adapter exact source.
    bfiles={s.rfilename:s for s in base_info.siblings}; assert any(x.endswith('.safetensors') for x in bfiles); assert not any(re.search(r'\.(bin|pt|pth|pkl|pickle)$',x,re.I) for x in bfiles)
    ad_dir=Path(snapshot_download(ADAPTER_REPO,revision=ADAPTER_REV,local_dir=raw/'adapter',allow_patterns=['adapter_model.safetensors','adapter_config.json','serving.json','tokenizer/*']))
    base_dir=Path(snapshot_download(BASE_REPO,revision=base_rev,local_dir=raw/'base',allow_patterns=['config.json','generation_config.json','*.safetensors','*.safetensors.index.json']))
    serving=json.loads((ad_dir/'serving.json').read_text()); assert serving['base_model']==BASE_REPO; assert serving['yes_id']==EXPECTED_YES_ID and serving['no_id']==EXPECTED_NO_ID and serving['max_len']==EXPECTED_MAX_LEN
    ad_sha=sha_bytes((ad_dir/'adapter_model.safetensors').read_bytes())
    # model source identity manifest, without shipping bytes
    base_manifest=[]
    for p in sorted(base_dir.rglob('*')):
      if p.is_file():base_manifest.append({'path':p.relative_to(base_dir).as_posix(),'bytes':p.stat().st_size,'sha256':sha_bytes(p.read_bytes())})
    # static anatomy before loading
    with safe_open(ad_dir/'adapter_model.safetensors',framework='pt',device='cpu') as sf:
      keys=list(sf.keys()); tensors={k:sf.get_tensor(k) for k in keys}
    pair_roots={}
    for k in keys:
      if '.lora_A.' in k:pair_roots.setdefault(k.split('.lora_A.')[0],{})['A']=k
      if '.lora_B.' in k:pair_roots.setdefault(k.split('.lora_B.')[0],{})['B']=k
    cfg=json.loads((ad_dir/'adapter_config.json').read_text()); scale=float(cfg['lora_alpha'])/float(cfg['r'])
    static=[]
    for root,ab in pair_roots.items():
      if set(ab)!={'A','B'}:continue
      A=tensors[ab['A']].float();B=tensors[ab['B']].float(); fam=next((f for f in ['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj'] if f in root),'other')
      lm=re.search(r'\.layers\.(\d+)\.',root); layer=int(lm.group(1)) if lm else -1
      static.append({'root_digest':sha_bytes(root.encode()),'family':fam,'layer':layer,'rank':int(A.shape[0]),'a_shape':list(A.shape),'b_shape':list(B.shape),'energy_proxy':float(torch.linalg.vector_norm(A)*torch.linalg.vector_norm(B)*scale),'a_finite':bool(torch.isfinite(A).all()),'b_finite':bool(torch.isfinite(B).all())})
    total_e=sum(x['energy_proxy'] for x in static) or 1.0; fam_energy=defaultdict(float); layer_energy=defaultdict(float)
    for x in static:fam_energy[x['family']]+=x['energy_proxy'];layer_energy[x['layer']]+=x['energy_proxy']
    static_public={'schema':'R22572_C56_STATIC_ATLAS_V1','pair_count':len(static),'rank_config':cfg['r'],'alpha':cfg['lora_alpha'],'zero_energy_pairs':sum(x['energy_proxy']==0 for x in static),'nonfinite_pairs':sum(not(x['a_finite'] and x['b_finite']) for x in static),'family_energy_share':{k:v/total_e for k,v in sorted(fam_energy.items())},'top_layer_energy_share':sorted(({'layer':k,'share':v/total_e} for k,v in layer_energy.items()),key=lambda x:-x['share'])[:8],'claim_boundary':'STATIC_CANDIDATE_ONLY__NORM_ENERGY_IS_NOT_CAUSAL'}
    # load exact runtime without remote code
    tok=AutoTokenizer.from_pretrained(ad_dir/'tokenizer',padding_side='left',trust_remote_code=False)
    base=AutoModelForCausalLM.from_pretrained(base_dir,torch_dtype=torch.float32,attn_implementation='sdpa',trust_remote_code=False).eval()
    peft=PeftModel.from_pretrained(base,ad_dir,adapter_name='default',is_trainable=False).eval()
    assert tok.vocab_size>max(serving['yes_id'],serving['no_id'])
    prefix=serving['prefix'];suffix=serving['suffix']; assert isinstance(prefix,str) and isinstance(suffix,str)
    def prompt(c):return prefix+f"<Instruct>: {c['instruction']}\n<Query>: {c['query']}\n<Document>: FINDING A:\n{c['a']}\n\nFINDING B:\n{c['b']}"+suffix
    @torch.inference_mode()
    def score_cases(subcases,batch=16,disable=False):
      ss=[]
      ctx=peft.disable_adapter() if disable else None
      if ctx:ctx.__enter__()
      try:
       for i in range(0,len(subcases),batch):
        texts=[prompt(c) for c in subcases[i:i+batch]]; enc=tok(texts,return_tensors='pt',padding=True,truncation=True,max_length=min(512,serving['max_len']),add_special_tokens=False)
        lg=peft(**enc,logits_to_keep=1).logits[:,-1,:]
        prob=torch.sigmoid(lg[:,serving['yes_id']]-lg[:,serving['no_id']]);ss.extend(float(x) for x in prob.cpu())
      finally:
       if ctx:ctx.__exit__(None,None,None)
      return ss
    # Capture original low-rank state only (no base cloning).
    params={n:p for n,p in peft.named_parameters() if '.lora_A.default.weight' in n or '.lora_B.default.weight' in n}
    originals={n:p.detach().cpu().clone() for n,p in params.items()}
    def restore():
      with torch.no_grad():
       for n,p in params.items():p.copy_(originals[n].to(p.device,p.dtype))
    def randomize():
      restore();g=torch.Generator(device='cpu');g.manual_seed(SEED+7)
      with torch.no_grad():
       for n,p in params.items():
        o=originals[n].float();r=torch.randn(o.shape,generator=g);r=r/(torch.linalg.vector_norm(r)+1e-12)*(torch.linalg.vector_norm(o)+1e-12);p.copy_(r.to(p.device,p.dtype))
    def shuffle_pairs():
      restore(); roots=defaultdict(dict)
      for n in params:
       if '.lora_A.default.weight' in n:roots[n.split('.lora_A.default.weight')[0]]['A']=n
       elif '.lora_B.default.weight' in n:roots[n.split('.lora_B.default.weight')[0]]['B']=n
      groups=defaultdict(list)
      for root,ab in roots.items():
       if set(ab)=={'A','B'}:groups[(tuple(originals[ab['A']].shape),tuple(originals[ab['B']].shape))].append(root)
      rng=random.Random(SEED+8)
      with torch.no_grad():
       for _,rs in groups.items():
        src=rs[:];rng.shuffle(src)
        for dst,sr in zip(rs,src):
         for side in ['A','B']:
          dn=roots[dst][side];sn=roots[sr][side];params[dn].copy_(originals[sn].to(params[dn].device,params[dn].dtype))
    def dose(d):
      restore()
      with torch.no_grad():
       for n,p in params.items():
        if '.lora_B.default.weight' in n:p.mul_(d)
    def ablate_family(fam):
      restore()
      with torch.no_grad():
       for n,p in params.items():
        if '.lora_B.default.weight' in n and f'.{fam}.' in n:p.zero_()
    def ablate_band(band):
      restore();layers=[]
      for n in params:
       m=re.search(r'\.layers\.(\d+)\.',n)
       if m:layers.append(int(m.group(1)))
      mx=max(layers);cut1=(mx+1)//3;cut2=2*(mx+1)//3
      def hit(l):return (l<cut1 if band=='early' else (cut1<=l<cut2 if band=='middle' else l>=cut2))
      with torch.no_grad():
       for n,p in params.items():
        m=re.search(r'\.layers\.(\d+)\.',n)
        if '.lora_B.default.weight' in n and m and hit(int(m.group(1))):p.zero_()
    # Behavior conditions.
    restore();base_scores=score_cases(cases,disable=True)
    restore();full_scores=score_cases(cases)
    randomize();rand_scores=score_cases(cases)
    shuffle_pairs();shuf_scores=score_cases(cases)
    dose_scores={}
    for d in [0.25,0.5,1.5]:dose(d);dose_scores[str(d)]=score_cases(cases)
    restore()
    cond={'BASE':metrics(cases,base_scores),'FULL':metrics(cases,full_scores),'RANDOM_RANK_MATCHED':metrics(cases,rand_scores),'LAYER_SHUFFLED':metrics(cases,shuf_scores)}
    for d,s in dose_scores.items():cond['DOSE_'+d.replace('.','p')]=metrics(cases,s)
    def composite(m):return 0.55*m['auc']+0.45*(m['pair_order_accuracy'] if m['pair_order_accuracy'] is not None else m['balanced_accuracy'])
    comp={k:composite(v) for k,v in cond.items()};ci=bootstrap_delta(cases,full_scores,base_scores)
    neg_fp_full=cond['FULL']['partitions']['negation']['positive_rate'];neg_fp_base=cond['BASE']['partitions']['negation']['positive_rate']
    pos=(comp['FULL']-comp['BASE']>=0.06 and ci['low']>0.01 and comp['FULL']-comp['RANDOM_RANK_MATCHED']>=0.04 and comp['FULL']-comp['LAYER_SHUFFLED']>=0.04 and cond['FULL']['pair_order_accuracy']-cond['BASE']['pair_order_accuracy']>=0.08 and neg_fp_full-neg_fp_base<=0.05)
    fail=(comp['FULL']-comp['BASE']<=-0.06 and ci['high']<-0.01 and comp['FULL']<min(comp['RANDOM_RANK_MATCHED'],comp['LAYER_SHUFFLED'])-0.04)
    causal=[]
    locked=[c for c in cases if c['partition'] in {'conjunction','directional'}]
    if pos or fail:
      restore();full_locked=score_cases(locked);fm=metrics(locked,full_locked);fc=composite(fm)
      for fam in ['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj']:
        ablate_family(fam);sc=score_cases(locked);mm=metrics(locked,sc);causal.append({'intervention':'MINUS_'+fam.split('_')[0].upper(),'composite':composite(mm),'drop_from_full_locked':fc-composite(mm),'n':len(locked)})
      for band in ['early','middle','late']:
        ablate_band(band);sc=score_cases(locked);mm=metrics(locked,sc);causal.append({'intervention':'MINUS_'+band.upper(),'composite':composite(mm),'drop_from_full_locked':fc-composite(mm),'n':len(locked)})
      restore()
    # No raw predictions exported; scalar counterexamples only.
    counter=[]
    for c,b,f,rn,sh in zip(cases,base_scores,full_scores,rand_scores,shuf_scores):
      if abs(f-b)>=0.20 or (int(f>=.5)!=c['label'] and int(b>=.5)==c['label']):
        counter.append({'id':c['id'],'partition':c['partition'],'rule_key':c['rule_key'],'label':c['label'],'base_score':round(b,6),'full_score':round(f,6),'random_score':round(rn,6),'shuffle_score':round(sh,6)})
    behavior={'schema':'R22572_C56_BEHAVIOR_V1','suite_n':len(cases),'suite_sha256':seal['suite_sha256'],'conditions':cond,'composite':comp,'full_minus_base_signed_margin_bootstrap95':ci,'positive_gate':bool(pos),'failure_gate':bool(fail),'causal_ran':bool(causal),'causal_screen':causal,'counterexample_scalar_count':len(counter),'claim_boundary':'Fresh synthetic relational-steering assay; no external benchmark claim. Positive/failure gates control causal entry; raw predictions not exported.'}
    prov={'schema':'R22572_C56_PROVENANCE_V1','adapter_repo':ADAPTER_REPO,'adapter_revision':ADAPTER_REV,'adapter_safetensors_sha256':ad_sha,'adapter_bytes':(ad_dir/'adapter_model.safetensors').stat().st_size,'adapter_license':'apache-2.0','base_repo':BASE_REPO,'runtime_reference_base_revision':base_rev,'training_time_base_revision_proven':False,'base_license':base_card.get('license'),'base_manifest':base_manifest,'serving_contract':{'yes_id':serving['yes_id'],'no_id':serving['no_id'],'max_len':serving['max_len'],'prefix_sha256':sha_bytes(prefix.encode()),'suffix_sha256':sha_bytes(suffix.encode())},'trust_remote_code':False,'pickle_consumed':False}
    (out/'C56_STATIC_ATLAS.json').write_text(json.dumps(static_public,indent=2))
    (out/'C56_BEHAVIOR.json').write_text(json.dumps(behavior,indent=2))
    (out/'C56_COUNTEREXAMPLES_SCALAR.json').write_text(json.dumps({'schema':'R22572_C56_COUNTEREXAMPLES_SCALAR_V1','items':counter},indent=2))
    (out/'C56_PROVENANCE.json').write_text(json.dumps(prov,indent=2))
    # destructive cleanup
    del peft,base,tok,tensors,originals,params
    import gc;gc.collect()
    shutil.rmtree(work,ignore_errors=True)
    hfhome=os.environ.get('HF_HOME');
    if hfhome:shutil.rmtree(hfhome,ignore_errors=True)
    (out/'C56_CLEANUP.json').write_text(json.dumps({'schema':'R22572_C56_CLEANUP_V1','controlled_cleanup':True,'raw_root_deleted':not work.exists(),'hf_cache_deleted':not(hfhome and Path(hfhome).exists()),'raw_weights_remaining':0,'raw_tokenizer_remaining':0},indent=2))
    print(json.dumps({'behavior':behavior,'static':static_public},indent=2)[:12000])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['preseal','execute']);ap.add_argument('--out',required=True);ap.add_argument('--work',default='c56-work');a=ap.parse_args();out=Path(a.out)
    if a.mode=='preseal':preseal(out)
    else:execute(out,Path(a.work))
if __name__=='__main__':main()
